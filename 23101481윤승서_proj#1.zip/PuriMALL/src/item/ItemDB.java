package item;

public class ItemDB extends ItemMain {
	public ItemDB(String name, Category category, int[] price, int[] inventory) {
		this.name = name;
		this.category = category;
		this.price = price;
		this.inventory = inventory;
	}
	
	public ItemDB(String name, Category category, int[] price, int []inventory, String[] option) {
		this.name = name;
		this.category = category;
		this.price = price;
		this.inventory = inventory;
		this.option = option;
	}
	
	@Override
	public void showItem() {
		lowInventory();
        System.out.println("상품명: " + name);
        System.out.println("카테고리: " + category);
        if (price.length == 1) {
            System.out.println("가격: " + price[0] + "원");
        } else {
        	System.out.println("가격: " + price[0] + "원");
        	for (int i=0; i<option.length; i++) {
        		System.out.println("  옵션 " + (i+1) + ": " + option[i]);
        	}
        }
    }
	
	public static void showAllItems() {
        System.out.println("=== 전체 상품 목록 ===");
        for (int i=0; i<ITEM.length; i++) {
        	ItemDB item = ITEM[i];
        	System.out.println("[" + (i + 1) + "] ");
        	item.showItem();
        	System.out.println("");
        }
    }

	public static final ItemDB[] ITEM = new ItemDB[] {
			new ItemDB("지우개패드 60매", Category.PAD, new int[]{14000, 25000}, new int[] {10, 10}, new String[] {"본품 1개", "본품 1개+리필 60매(+11000)"}),
			new ItemDB("시카 지우개패드 60매", Category.PAD, new int[] {17900, 32900}, new int[] {10, 10}, new String[] {"본품 1개", "본품 1개+리필 60매(+15000)"}),
			new ItemDB("노니 글로우 패드 50매", Category.PAD, new int[] {18900, 34900}, new int[] {10, 10}, new String[] {"본품 1개", "본품 1개+리필 50매(+16000)"}),
			new ItemDB("노니 에너지 앰플 30ml", Category.AMPOULE_SERUM, new int[] {20900, 30900}, new int[] {10, 10}, new String[] {"30ml 1개", "50ml 1개(+10000)"}),
			new ItemDB("나이아시아마이드 시카 흔적 세럼 40ml", Category.AMPOULE_SERUM, new int[] {16900}, new int[] {10}),
			new ItemDB("노니 앰플 에어리스 100ml", Category.AMPOULE_SERUM, new int[] {40000}, new int[] {10}),
			new ItemDB("시카 수딩 크림 50ml", Category.LOTION_CREAM, new int[] {15300}, new int[] {10}),
			new ItemDB("노니 퍼밍 로션 150ml", Category.LOTION_CREAM, new int[] {24000, 43000}, new int[] {10, 10},  new String[] {"150ml 1개", "150ml 1개+노니 에너지 앰플 30ml(+19000)"}),
			new ItemDB("지우개 폼 클렌징 150ml", Category.CLEANSING, new int[] {6800, 11800}, new int[] {10, 10}, new String[] {"본품 1개", "본품 2개(+5000)"}),
			new ItemDB("시카 바하 지우개 폼 클렌징", Category.CLEANSING, new int[] {10000, 18000}, new int[] {10, 10}, new String[] {"본품 1개", "본품 2개(+8000)"}),
			new ItemDB("시카 세럼 마스크", Category.MASK, new int[] {3000, 27000}, new int[] {10, 10}, new String[] {"본품 1매", "본품 10매(+24000)"}),
			new ItemDB("노니 엠플 마스크", Category.MASK, new int[] {4000, 36000}, new int[] {10, 10}, new String[] {"본품 1매", "본품 10매(+32000)"})
	};
}