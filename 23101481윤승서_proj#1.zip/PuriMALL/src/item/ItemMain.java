package item;

public class ItemMain {

	public enum Category {PAD, AMPOULE_SERUM, LOTION_CREAM, CLEANSING, MASK}

	public String name;
	public Category category;
	public int[] price;
	public int[] inventory;
	public String[] option;
	public int optionIndex = 0;
	public int quantity = 1;
	public int finalPrice;
	
	public String getName() { return name; }
	public Category getCategory() { return category; }
	public int[] getPrice() { return price; }
	public int[] getInventory() { return inventory; }
	public String[] getOption() { return option; }
	public int getQuantity() { return quantity; }
	
	public void lowInventory() {
		if (inventory.length > 1) {
			for (int i=0; i<inventory.length; i++) {
				if (this.inventory[i] == 0) {
					System.out.println("[품절] " + "[옵션 " + (i+1) + ": " + this.option[i] + "] ");
				}
				if (this.inventory[i] < 3 && this.inventory[i] > 0) {
					System.out.println("[품절 임박] " + "[옵션 " + (i+1) + ": " + this.option[i] + "] " + this.inventory[i] + "개 남음");
				}
			}
		} else {
			if (this.inventory[0] == 0) {
				System.out.println("[품절]");
			}
			if (this.inventory[0] < 3 && this.inventory[0] > 0)
			System.out.println("[품절 임박] "  + this.inventory[0] + "개 남음");
		}
	}
	
	public void showItem() {
		lowInventory();
        System.out.println("상품명: " + name);
        System.out.println("카테고리: " + category);
        System.out.println("가격: " + price[0] + "원");
	}
	
	public void selectOption(int optionNum) {
		int index = optionNum - 1;
	    if (index < 0 || index >= price.length) {
	   		System.out.println("잘못된 옵션 번호입니다. 다시 선택해주세요.");
	   		return;
	   	} else {
	   		finalPrice = price[index];
	   		optionIndex = index;
	   		System.out.println("[" + option[index] + "] " + option[index] + "' 옵션이 선택되었습니다.");
	   		System.out.println("최종가: " + finalPrice + "원");
	   	}
	}
	
	public void selectQuantity(int q, int o) {
		if (price.length > 1) {
			if (q > inventory[o - 1])
				System.out.println("재고가 부족합니다. " + inventory[o - 1] + "개 이하로 구매할 수 있습니다.");
		} else {
			if (q > inventory[0]) {
				System.out.println("재고가 부족합니다. " + inventory[0] + "개 이하로 구매할 수 있습니다.");
			}
		}
	    quantity = q;
	    System.out.println(quantity + "개가 선택되었습니다.");
	}
}
