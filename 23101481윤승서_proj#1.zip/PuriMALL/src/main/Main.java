package main;

import java.util.InputMismatchException;
import java.util.Scanner;

import item.ItemDB;
import manage.Search;
import manage.OrderCheck;
import manage.Order;
import manage.Cart;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Search search = new Search(sc);
		OrderCheck ordercheck = new OrderCheck(sc);
		Order order = new Order(sc);
		Cart cart = new Cart(sc);
		
		System.out.println("PuriMall에 오신 것을 환영합니다.");
		
		while(true) {
			System.out.println("=========================");
			System.out.println("  1. 상품");
			System.out.println("  2. 상품 검색");
			System.out.println("  3. 장바구니 확인");
			System.out.println("  4. 구매내역 확인");
			System.out.println("  0. 종료");
			System.out.print("원하시는 번호를 입력해주세요: ");
			int input1 = sc.nextInt();
			switch(input1) {
			case 1:
				while(true) {
					System.out.println("=====");
					ItemDB.showAllItems();
					System.out.println("0. 뒤로 가기");
					System.out.println("=====");
					System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
					try {
						int input3 = sc.nextInt();
						if (input3 < 0 || input3 > ItemDB.ITEM.length) {
							System.out.println("다시 입력해주세요.");
							continue;
						}
						if (input3 == 0) {
							break;
						}
						ItemDB selitem = ItemDB.ITEM[input3 -1];
						Cart.addtoCart(selitem);
					} catch (InputMismatchException e) {
						System.out.println("숫자를 입력해주세요: ");
						sc.nextLine();
						continue;
					}
				}
				continue;
			case 2:
				Search.search();
				continue;
			case 3:
				while(true) {
					Cart.showCart();
					System.out.println("=========================");
					System.out.println("  1. 장바구니 상품 주문");
					System.out.println("  2. 선택 상품 삭제");
					System.out.println("  3. 전체 상품 삭제");
					System.out.println("  0. 뒤로 가기");
					System.out.println("=====");
					System.out.print("원하시는 번호를 입력해주세요: ");
					try {
						int input4 = sc.nextInt();
						switch(input4) {
							case 1:
								System.out.println("=====");
								if (cart.getCartCount() == 0) {
									System.out.println("장바구니가 비어있습니다.");
									break;
								}
								Order.order(cart);
								continue;
							case 2:
								System.out.println("=====");
								if (cart.getCartCount() == 0) {
									System.out.println("장바구니가 비어있습니다.");
									break;
								}
								System.out.println("선택 상품 삭제 - 상품 번호 / 선택 상품 일부 삭제 - 상품 번호 삭제 개수");
								System.out.println("ex. 1 or 1 2");
								System.out.print("입력해주세요: ");
								try {
									input4 = sc.nextInt();
									String temp1 = sc.nextLine();
									Scanner temp2 = new Scanner(temp1);
									if (temp2.hasNextInt()) {
										int input41 = temp2.nextInt();
										cart.deleteItem(input4, input41);
									} else {
										cart.deleteItem(input4);
									}
									temp2.close();
								} catch (IllegalStateException e) {  // java.lang에 있어서 자동 import
									System.out.println("잘못된 입력입니다.");
									sc.nextLine();
									continue;
								}
								continue;
							case 3:
								System.out.println("=====");
								if (cart.getCartCount() == 0) {
									System.out.println("장바구니가 비어있습니다.");
									break;
								}
								while(true) {
									System.out.print("전체 삭제하시겠습니까? [Y/N]: ");
									String input5 = sc.next();
									switch(input5) {
										case "Y":
											cart.clearCart();
											break;
										case "N":
											System.out.println("=====");
											System.out.println("취소되었습니다.");
											System.out.println("=====");
											break;
										default:
											System.out.println("=====");
											System.out.println("다시 입력해주세요.");
											System.out.println("=====");
											continue;
									}
									break;
								}
								continue;
							case 0:
								break;
							default:
								System.out.println("다시 선택해주세요.");
								sc.nextInt();
								continue;
						}
						break;
					} catch (InputMismatchException e) {
						System.out.println("숫자를 입력해주세요.");
						sc.nextLine();
						continue;
					}
				}
				continue;
			case 4:
				while(true) {
					System.out.println("=== 구매내역 확인 ===");
					System.out.println("원하시는 번호를 입력해주세요.");
					System.out.println("  1. 최근 구매내역 10건 확인");
					System.out.println("  2. 주문자 이름 검색");
					System.out.println("  0. 뒤로 가기");
					System.out.print("번호 입력: ");
					try {
						int input2 = sc.nextInt();
						switch(input2) {
							case 1:
								Order.showOrder();
								continue;
							case 2:
								OrderCheck.ordercheck();
								continue;
							case 0:
								break;
							default:
								System.out.println("다시 선택해주세요.");
								sc.nextInt();
								continue;
						}
					break;
					} catch (InputMismatchException e) {
						System.out.println("숫자를 입력해주세요.");
						sc.nextLine();
						continue;
					}
				}
				continue;
			case 0:
				System.out.println("=========================");
				System.out.println("이용해주셔서 감사합니다. - PuriMall");
				sc.close();
				return;
			default:
				System.out.println("다시 선택해주세요.");
				System.out.print("번호 입력: ");
				input1 = sc.nextInt();
		}
		}
	}
}
