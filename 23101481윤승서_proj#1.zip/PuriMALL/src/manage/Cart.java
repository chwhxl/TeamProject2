package manage;

import java.util.InputMismatchException;
import java.util.Scanner;

import item.ItemDB;

public class Cart {
	private static Scanner sc;
	
	public Cart(Scanner sc) {
		Cart.sc = sc;
	}
	
	public static class CartItem {
        public String name;
        public String[] option;
        public int[] priceop;
        public int[] price;
        public int[] inventory;
        public int optionIndex;
        public int quantity;

        public int totalpriceop() {
            return priceop[optionIndex] * quantity;
        }
        
        public int totalprice() {
        	return price[0] * quantity;
        }
	}
	
	private static CartItem[] cart = new CartItem[10];
    private static int count = 0;
    
    public static int getQuantity() {
    	int total = 0;
    	for (int i=0; i<count; i++) {
            total += cart[i].quantity;
        }
        return total;
    }
    
    public int getCartCount() {
    	return count;
    }
    
    public CartItem getItem(int i) {
    	return cart[i];
    }
    
    public static void addtoCart(ItemDB db) {    	
        if (getQuantity() == 10) {
            System.out.println("장바구니가 가득 찼습니다.");
            return;
        }
         
        CartItem item = new CartItem();
        item.name = db.getName();
        item.option = db.getOption();
        item.priceop = db.getPrice();
        item.price = db.getPrice();
        item.inventory = db.getInventory();       
        
        if (item.priceop.length == 1) {
            System.out.println("=====");
    		System.out.println("선택한 상품: " + item.name);
            System.out.println("가격: " + item.priceop[0]);
            System.out.println("0. 뒤로 가기");
        } else {
        	item.optionIndex = 0;
        	while(true) {
            	int selectedop;
            	System.out.println("=====");
				System.out.println("선택한 상품: " + item.name);
            	System.out.println("가격: " + item.priceop[0]);
            	System.out.println("옵션 1: " + item.option[0] + " / " + "옵션 2: " + item.option[1]);
            	System.out.println("0. 뒤로 가기");
            	System.out.println("=====");
            	System.out.print("원하시는 옵션 또는 0을 입력해주세요: ");
    			try {
    				selectedop = sc.nextInt();
    				sc.nextLine();
    			} catch (InputMismatchException e) {
    	                System.out.println("숫자를 입력해주세요.");
    	                sc.nextLine();
    	                continue;
    			}
    			if (item.inventory[selectedop - 1] == 0) {
    	    		System.out.println("품절된 상품입니다.");
    	    		return;
    	    	}
    			if (selectedop == 0) {
    				return;
    			}
    			if (selectedop != 1 && selectedop != 2) {  // 옵션은 2개 밖에 없음
    				System.out.println("다시 입력해주세요.");
    				continue;
    			}
    			item.optionIndex = selectedop - 1;
    			break;
            }
        }
        
		int selectedquan;
		while(true) {
			System.out.println("=====");
			System.out.print("원하시는 수량 또는 0을 입력해주세요: ");
			try {
				selectedquan = sc.nextInt();
				if (selectedquan == 0) {
					return;
				}
			} catch (InputMismatchException e) {
	                System.out.println("숫자를 입력해주세요.");
	                sc.nextLine();
	                continue;
			}
			if (selectedquan > 10) {
				System.out.println("구매 수량은 10개를 초과할 수 없습니다.");
				continue;
			}
			if (selectedquan < 0) {
				System.out.println("수량은 1개 이상이어야 합니다.");
				continue;
			}
			if ((selectedquan + getQuantity()) > 10) {
				System.out.println("장바구니 상품이 10개를 초과합니다. 더 이상 담을 수 없습니다.");
				break;
			}
			if (selectedquan > item.inventory[item.optionIndex]) {
				System.out.println("재고가 부족합니다. " + item.inventory[item.optionIndex] + "개 이하로 담을 수 있습니다.");
				break;
			}
			break;
		}
		if (getQuantity() >= 10) {
			System.out.println("장바구니가 가득 찼습니다.");
			return;
		} else if((selectedquan + getQuantity()) > 10) {
			return;
		} else {
			for (int i=0; i<count; i++) {
				if (cart[i].name.equals(db.getName()) && cart[i].optionIndex == item.optionIndex) {
					cart[i].quantity += selectedquan;
					return;
				}
			}
			item.quantity = selectedquan;
			cart[count++] = item;
			System.out.println("=====");
			System.out.println("장바구니에 담았습니다.");
		}
    }
    
    public static int getTotal() {
    	int sum = 0;
        for (int i=0; i<count; i++) {
        	CartItem item = cart[i];
        	if (item.priceop.length > 1) {
        		sum += item.totalpriceop();
        	} else {
        		sum += item.totalprice();
        	}
        }
        return sum;
    }

    public static void showCart() {
        if (count == 0) {
            System.out.println("장바구니가 비어 있습니다.");
            return;
        }

        System.out.println("=== 장바구니 목록 ===");
        System.out.println("현재 장바구니 상품 수: " + count + "개");
        System.out.println("=====");
        for (int i=0; i<count; i++) {
            CartItem item = cart[i];
            if (item.priceop.length > 1) {  // error 해결 -> option 개수 말고 price length 로 조건 작성
            	String ciOption = item.option[item.optionIndex];
            	System.out.println("[" + (i + 1) + "]  " + item.name + " / " + ciOption + " / " + item.quantity + "개 / " + item.totalpriceop() + "원");  // option string
            } else {
            	System.out.println("[" + (i + 1) + "]  " + item.name + " / " + item.quantity + "개 / " + item.totalprice() + "원");  // error !! + total price error
            }
        }
        System.out.println("=====");
        System.out.println("총 결제 금액: " + getTotal() + "원");
    }

    public void deleteItem(int num) {
        int index = num - 1;
        
        if (index < 0 || index >= count) {
            System.out.println("잘못된 상품 번호입니다. 다시 선택해주세요.");
            return;
        }
        for (int i=index; i<(count - 1); i++) {
            cart[i] = cart[i + 1];
        }
        cart[count - 1] = null;
        count--;
        System.out.println("=====");
        System.out.println("선택한 상품이 삭제되었습니다.");
        System.out.println("현재 장바구니 상품 수: " + count + "개");
        System.out.println("=========================");
    }
    
    public void deleteItem(int num1, int num2) {
    	int index = num1 - 1;
    	
    	if (index < 0 || index >= count) {
    		System.out.println("잘못된 상품 번호입니다. 다시 선택해주세요.");
    		return;
    	}
    	if (num2 <= 0) {
            System.out.println("1개 이상부터 삭제할 수 있습니다.");
            return;
        }
    	if (num2 > cart[index].quantity) {
    		System.out.println("장바구니에 담긴 상품 수를 초과했습니다.");
    		return;
    	}
    	cart[index].quantity -= num2;
    	if (cart[index].quantity == 0) {
    		for (int i=index; i<(count - 1); i++) {
    			cart[i] = cart[i + 1];
    		}
        	cart[count - 1] = null;
    		count--;
    	}
    	System.out.println("=====");
        System.out.println("선택한 상품이 삭제되었습니다.");
        System.out.println("현재 장바구니 상품 수: " + count + "개");
        System.out.println("=========================");
    }
    
    public void clearCart() {
    	if (count == 0) {
            System.out.println("장바구니가 비어 있습니다.");
            return;
        }
    	for (int i = 0; i < count; i++) {
    		cart[i] = null;
    	}
    	count = 0;
        System.out.println("장바구니 내 상품이 전체 삭제되었습니다");
    }
}
