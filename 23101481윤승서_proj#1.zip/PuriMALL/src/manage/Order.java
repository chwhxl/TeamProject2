package manage;

import java.util.Scanner;

import item.ItemDB;

public class Order {
	private static Scanner sc;
	
	public Order(Scanner sc) {
		Order.sc = sc;
	}
	
	protected static class OrderData {
		int num;
		String name;
		int itemprice;
		int totalprice;
		String[] ordereditem;
	}
	protected static final OrderData[] orderList = new OrderData[10];
	protected static int orderCount = 0;
	private static int listcount = 0;
	
	public static void order(Cart cart) {
		if (cart == null || Cart.getQuantity() == 0) {
            System.out.println("장바구니가 비어 있습니다. 주문을 진행할 수 없습니다.");
            return;
        }
		System.out.println("=== 주문 ===");
		System.out.print("주문자 이름을 입력해주세요(공백없이): ");
		String name = sc.next();
		System.out.println("총 결제 금액: " + Cart.getTotal() + "원");
		System.out.println("=====");
		System.out.print("주문 하시겠습니까? [Y/N]: ");
		String ans = sc.next();
		while(true) {
			switch(ans) {
				case "Y":
					if (orderCount < 10) {
						OrderData list = new OrderData();
						list.num = ++listcount;
						list.name = name;
						list.totalprice = Cart.getTotal();
		            	orderList[orderCount++] = list;
		            	int cartcount = cart.getCartCount();
		            	list.ordereditem = new String[cartcount];
		            	for (int i=0; i<cartcount; i++) {
		            		Cart.CartItem ci = cart.getItem(i);
		            		String ciOption = ((ci.price.length > 1) ? ci.option[ci.optionIndex] : "-");
		            		int tp = ((ci.priceop.length > 1) ? ci.totalpriceop() : ci.totalprice());
		            		list.ordereditem[i] = ci.name + "(" + ciOption + ") " + ci.quantity + "개 - " + tp + "원";
		            		for (int j=0; j<ItemDB.ITEM.length; j++) {
		            			if (ItemDB.ITEM[j].getName().equals(ci.name) == true) {
		            				ItemDB.ITEM[j].inventory[ci.optionIndex] -= ci.quantity;
		            				break;
		            			}
		            		}
		            	}
		            	System.out.println("주문이 완료되었습니다. 주문번호: " + list.num);
		            	System.out.println("=====");
		            	cart.clearCart();
		            	System.out.println("=====");
		            	break;
					} else {
						for (int i=0; i<(orderCount - 1); i++) {
							orderList[i] = orderList[i + 1];
						}
						OrderData list = new OrderData();
						list.num = ++listcount;
						list.name = name;
						list.totalprice = Cart.getTotal();
						orderList[orderCount - 1] = list;
						int cartcount = cart.getCartCount();
						list.ordereditem = new String[cartcount];
						for (int i=0; i<cartcount; i++) {
							Cart.CartItem ci = cart.getItem(i);
							String oiOption = ((ci.price.length > 1) ? ci.option[ci.optionIndex] : "-");
							int tp = ((ci.priceop.length > 1) ? ci.totalpriceop() : ci.totalprice());
		            		list.ordereditem[i] = ci.name + "(" + oiOption + ") " + ci.quantity + "개 - " + tp + "원";
		            		for (int j=0; j<ItemDB.ITEM.length; j++) {
		            			if (ItemDB.ITEM[j].getName().equals(ci.name) == true) {
		            				ItemDB.ITEM[j].inventory[ci.optionIndex] -= ci.quantity;
		            				break;
		            			}
		            		}
						}
						System.out.println("주문이 완료되었습니다. 주문번호: " + list.num);
						System.out.println("=====");
						cart.clearCart();
						System.out.println("=========================");
						break;
					}
				case "N":
					System.out.println("주문이 취소되었습니다.");
					System.out.println("=========================");
					break;
				default:
					System.out.println("다시 입력해주세요.");
					System.out.print("주문 하시겠습니까? [Y/N]: ");
					ans = sc.next();
					continue;
				}
			break;
			}
		}
	
	public static void showOrder() {
		if (orderCount == 0) {
			System.out.println("주문 내역이 없습니다.");
			System.out.println("=========================");
			return;
		} else {
			for(int i=0; i<orderCount; i++) {
				System.out.println("=====");
				System.out.println("[" + (i+1) + "]");
				System.out.println("주문자: " + orderList[i].name);
				System.out.println("주문 내역: ");
				String[] item = orderList[i].ordereditem;
				for (int j=0; j<item.length; j++) {
					System.out.println("  [" + (j + 1) + "] " + item[j]);
				}
				System.out.println("총 금액: " + orderList[i].totalprice + "원");
			}
			System.out.println("=========================");
		}
	}
}
