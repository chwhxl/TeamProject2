package manage;

import java.util.Scanner;

public class OrderCheck {
	static int i;
	private static Scanner sc;
	
	public OrderCheck(Scanner sc) {
		OrderCheck.sc = sc;
	}
	
	public static void ordercheck() {
		int count = 1;
		
		if (Order.orderCount == 0) {
			System.out.println("주문 내역이 없습니다.");
			System.out.println("=====");
			return;
		}
		
		System.out.print("주문자 이름을 입력해주세요(공백없이): ");
		String orderer = sc.next();
		System.out.println("=== 검색 결과 ===");
		for (i=0; i<Order.orderCount; i++) {
			String tempname = Order.orderList[i].name;
			if (orderer.equals(tempname) == true) {
				System.out.println("[" + count + "]");
				System.out.println("주문자: " + tempname);
				System.out.println("주문 내역: ");
				String[] list = Order.orderList[i].ordereditem;
				for(int j=0; j<list.length; j++) { // range 설정이 잘못되어 있었음
					try {
					System.out.println("  [" + (j + 1) + "] " + list[j]);  // index range error 해결!
					} catch (ArrayIndexOutOfBoundsException e) {
						System.out.println("array index exception 발생");
						break;
					}
				}
				System.out.println("총 금액: " + Order.orderList[i].totalprice + "원");
				System.out.println("=========================");
				count++;
			}
		}
		if (count == 1) {
			System.out.println("일치하는 이름이 없습니다.");
			System.out.println("=========================");
			return;
		} 
	}
}
