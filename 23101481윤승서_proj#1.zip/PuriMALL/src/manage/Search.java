package manage;

import java.util.Scanner;
import java.util.InputMismatchException;

import item.ItemDB;

public class Search {
	private static Scanner sc;
	
	public Search(Scanner sc) {
		Search.sc = sc;
	}
	
	public static void search() {
		while(true) {
			System.out.println("=== 상품 검색 ===");
			System.out.println("원하시는 번호를 입력해주세요.");
			System.out.println("  1. 이름으로 검색");
			System.out.println("  2. 카테고리로 검색");
			System.out.println("  3. 가격으로 검색");
			System.out.println("  0. 뒤로 가기");
			System.out.print("번호 입력: ");
			try {
				int input = sc.nextInt();
				
				switch(input) {
					case 1:
						searchName();
						break;
					case 2:
						searchCategory();
						break;
					case 3:
						searchPrice();
						break;
					case 0:
						return;
					default:
						System.out.println("다시 선택해주세요.");
				}
			} catch (InputMismatchException e) {
	                System.out.println("숫자를 입력해주세요.");
	                sc.nextLine();
			}
		}
	}
	
	public static void searchName() {
		int count = 1;
		
		sc.nextLine();
		System.out.println("=====");
		System.out.print("검색어를 입력하세요: ");
		String itemname = sc.nextLine();
		System.out.println("=== 검색 결과 ===");
		ItemDB[] searchitem = new ItemDB[10];
		for (int i=0; i<ItemDB.ITEM.length; i++) {
			String tempname = ItemDB.ITEM[i].getName();
			if (tempname.indexOf(itemname) != -1) {
				System.out.println("[" + count + "]");
				searchitem[count -1] = ItemDB.ITEM[i];
				ItemDB.ITEM[i].showItem();
				count++;
			}
		}
		if (count != 1) {
			System.out.println("0. 뒤로 가기");
			while(true) {
				System.out.println("=====");
				System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
				int input = sc.nextInt();
				if (input < 0 || input >= count) {
					System.out.println("다시 입력해주세요.");
					continue;
				}
				if (input == 0) {
					break;
				}
				Cart.addtoCart(searchitem[input - 1]);
			}
		}
		if (count == 1) {
			System.out.println("검색 결과가 없습니다.");
			System.out.println("=====");
		}
	}
	
	public static void searchCategory() {
		while(true) {
			System.out.println("== 카테고리를 선택해주세요. ==");
			System.out.println("  1. 패드");
			System.out.println("  2. 앰플/세럼");
			System.out.println("  3. 로션/크림");
			System.out.println("  4. 클렌징");
			System.out.println("  5. 마스크");
			System.out.println("  0. 뒤로 가기");
			System.out.print("번호 입력: ");
			
			try {
				int catenum = sc.nextInt();
				int count = 1;
				int i;
					
				switch(catenum) {
					case 1:
						ItemDB[] selitem1 = new ItemDB[10];
						System.out.println("== 패드 ==");
						for (i=0; i<ItemDB.ITEM.length; i++) {
							if (ItemDB.ITEM[i].getCategory() == ItemDB.Category.PAD) {
								System.out.println("[" + count + "]");
								selitem1[count - 1] = ItemDB.ITEM[i];
								ItemDB.ITEM[i].showItem();
								count++;
							}
						}
						if (count != 1) {
							System.out.println("0. 뒤로 가기");
							while(true) {
								System.out.println("=====");
								System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
								int input = sc.nextInt();
								if (input < 0 || input > count) {
									System.out.println("다시 입력해주세요.");
									continue;
								}
								if (input == 0) {
									break;
								}
								Cart.addtoCart(selitem1[input - 1]);
							}
						}
						if (count == 1) {
							System.out.println("검색 결과가 없습니다.");
							System.out.println("=====");
						}
						break;
					case 2:
						count = 1;
						ItemDB[] selitem2 = new ItemDB[10];
						System.out.println("== 앰플/세럼 ==");
						for (i=0; i<ItemDB.ITEM.length; i++) {
							if (ItemDB.ITEM[i].getCategory() == ItemDB.Category.AMPOULE_SERUM) {
								System.out.println("[" + count + "]");
								selitem2[count - 1] = ItemDB.ITEM[i];
								ItemDB.ITEM[i].showItem();
								count++;
							}
						}
						if (count != 1) {
							System.out.println("0. 뒤로 가기");
							while(true) {
								System.out.println("=====");
								System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
								int input = sc.nextInt();
								if (input < 0 || input > count) {
									System.out.println("다시 입력해주세요.");
									continue;
								}
								if (input == 0) {
									break;
								}
								Cart.addtoCart(selitem2[input - 1]);
							}
						}
						if (count == 1) {
							System.out.println("검색 결과가 없습니다.");
							System.out.println("=====");
						}
						break;
					case 3:
						count = 1;
						ItemDB[] selitem3 = new ItemDB[10];
						System.out.println("== 로션/크림 ==");
						for (i=0; i<ItemDB.ITEM.length; i++) {
							if (ItemDB.ITEM[i].getCategory() == ItemDB.Category.LOTION_CREAM) {
								System.out.println("[" + count + "]");
								selitem3[count - 1] = ItemDB.ITEM[i];
								ItemDB.ITEM[i].showItem();
								count++;
							}
						}
						if (count != 1) {
							System.out.println("0. 뒤로 가기");
							while(true) {
								System.out.println("=====");
								System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
								int input = sc.nextInt();
								if (input < 0 || input > count) {
									System.out.println("다시 입력해주세요.");
									continue;
								}
								if (input == 0) {
									break;
								}
								Cart.addtoCart(selitem3[input - 1]);
							}
						}
						if (count == 1) {
							System.out.println("검색 결과가 없습니다.");
							System.out.println("=====");
						}
						break;
					case 4:
						count = 1;
						ItemDB[] selitem4 = new ItemDB[10];
						System.out.println("== 클렌징 ==");
						for (i=0; i<ItemDB.ITEM.length; i++) {
							if (ItemDB.ITEM[i].getCategory() == ItemDB.Category.CLEANSING) {
								System.out.println("[" + count + "]");
								selitem4[count - 1] = ItemDB.ITEM[i];
								ItemDB.ITEM[i].showItem();
								count++;
							}
						}
						if (count != 1) {
							System.out.println("0. 뒤로 가기");
							while(true) {
								System.out.println("=====");
								System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
								int input = sc.nextInt();
								if (input < 0 || input > count) {
									System.out.println("다시 입력해주세요.");
									continue;
								}
								if (input == 0) {
									break;
								}
								Cart.addtoCart(selitem4[input - 1]);
							}
						}
						if (count == 1) {
							System.out.println("검색 결과가 없습니다.");
							System.out.println("=====");
						}
						break;
					case 5:
						count = 1;
						ItemDB[] selitem5 = new ItemDB[10];
						System.out.println("== 마스크 ==");
						for (i=0; i<ItemDB.ITEM.length; i++) {
							if (ItemDB.ITEM[i].getCategory() == ItemDB.Category.MASK) {
								System.out.println("[" + count + "]");
								selitem5[count - 1] = ItemDB.ITEM[i];
								ItemDB.ITEM[i].showItem();
								count++;
							}
						}
						if (count != 1) {
							System.out.println("0. 뒤로 가기");
							while(true) {
								System.out.println("=====");
								System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
								int input = sc.nextInt();
								if (input < 0 || input > count) {
									System.out.println("다시 입력해주세요.");
									continue;
								}
								if (input == 0) {
									break;
								}
								Cart.addtoCart(selitem5[input - 1]);
							}
						}
						if (count == 1) {
							System.out.println("검색 결과가 없습니다.");
							System.out.println("=====");
						}
						break;
					case 0:
						return;
					default:
						System.out.println("다시 선택해주세요.");
				}
			} catch (InputMismatchException e) {
				System.out.println("숫자를 입력해주세요.");
	            sc.nextLine();
			}
		}
	}
	
	public static void searchPrice() {		
		System.out.println("=====");
		System.out.print("가격 범위를 입력해주세요(ex.10000 15000): ");
		
		try {
			int count = 1;
			int pricenum1 = sc.nextInt();
			int pricenum2 = sc.nextInt();
			ItemDB[] selitem = new ItemDB[10];
			System.out.println("=== 검색 결과 ===");
			for (int i=0; i<ItemDB.ITEM.length; i++) {
				int[] itemprice = ItemDB.ITEM[i].getPrice();
				if ((itemprice[0] >= pricenum1) && (itemprice[0] <= pricenum2)) {
					System.out.println("[" + count + "]");
					selitem[count - 1] = ItemDB.ITEM[i];
					ItemDB.ITEM[i].showItem();
					count++;
				}
			}
			if (count != 1) {
				System.out.println("0. 뒤로 가기");
				while(true) {
					System.out.println("=====");
					System.out.print("원하시는 상품의 번호 또는 0을 입력해주세요: ");
					int input = sc.nextInt();
					if (input < 0 || input > count) {
						System.out.println("다시 입력해주세요.");
						continue;
					}
					if (input == 0) {
						break;
					}
					Cart.addtoCart(selitem[input -1]);
				}
			}
			if (count == 1) {
				System.out.println("검색 결과가 없습니다.");
				System.out.println("=====");
			}
		} catch (InputMismatchException e) {
			System.out.println("숫자를 입력해주세요.");
	        sc.nextLine();
		} catch (IllegalArgumentException e) {
	        System.out.println("범위가 잘못되었습니다. 작은수 큰수 순으로 입력해주세요.");
	        sc.nextLine();
	    }
	}
}
