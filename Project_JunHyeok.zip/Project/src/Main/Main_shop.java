package Main;
import java.util.InputMismatchException;
import java.util.Scanner;
import Product.*;
import User.*;
public class Main_shop {
	
	
	public static User u = new User();
	public static final Scanner SC = new Scanner(System.in);
	
	public static int menu() {
		int k;
		
			while(true) {
				try { //정수 값 입력이 아닐시 다시 입력하게 함.
					for (int i = 0; i < 15; i++) System.out.println();
					System.out.println("======================================");
					System.out.println("Welecome to the HIPHOP ALBUM SHOP!!");
					System.out.println(" 0: Out \t\t 1: Search \n 2: Cart \t 3: Buy \n 4: Refund \t 5: Lotto\n 6: Charge Wallet");
					System.out.println("======================================");
					System.out.println("Your money: " + u.Wallet + " Won.");
					System.out.print("Choose the Menu(0~5): ");

					
					k = SC.nextInt();
					SC.nextLine();
					switch(k) {
						case 0:{
							System.out.println("Thank You For Using! Good Bye.");
							return k; //exit
						}case 1:{
							//Search
							management.Search();
							SC.nextLine();
							break;
						}case 2:{
							//cart
							User.c.Cart();
							SC.nextLine();
							break;
						}case 3:{
							//Payment
							management.buy();
							SC.nextLine();
							break;
						}case 4:{
							//Refund
							management.Refund();
							SC.nextLine();
							break;
						}case 5:{
							//LOTTO
							u.l.LOTTO();
							break;
						}case 6:{
							//Charge Wallet
							management.ChargeMoney();
							SC.nextLine();

							SC.nextLine();
							break;
						}default:{
							System.out.println("⚠️ Please Enter correct value!(0~3)");
						}
					}
					
				} catch(InputMismatchException e) {
					System.out.print("⚠️ Please Enter integer value!");
					SC.nextLine();
					SC.nextLine();
				}
			}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int k = menu();
		SC.close();
	}

}
