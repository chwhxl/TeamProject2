package Main;
import Product.storage;
import User.*;
import java.util.*;
public class management {
	
	public static void buy() { //구매
		int pay = 0;
		System.out.println("In Your Cart:");
		try {
			for(int i = 0;i<Product.storage.cart.length;i++) {
				if(Product.storage.cart[i].getnum() > 0){
					Product.storage.cart[i].show();
					pay += Product.storage.cart[i].getprice() * Product.storage.cart[i].getnum();
				}
			}	
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
		}
		if (pay == 0) {	System.out.println("Your Cart is Empty");	}
		else{	
			int k =Payment(pay);
			if (k==0) {
				for(int i = 0;i<Product.storage.cart.length;i++) {
					if(Product.storage.cart[i].getnum() > 0){
						Product.storage.buy[i].setnum(Product.storage.cart[i].getnum()); //cart에서 buy로 넘기기
						Product.storage.cart[i].setnum(0); //cart 안의 num 0으로 만들기.
					}
				}
			}
		} //돈 결제
	}
	
	public static int Payment(int pay) {//지갑에서 돈 차감
		if (Main_shop.u.Wallet - pay >= 0) {
			Main_shop.u.Wallet -= pay;
			System.out.print("-" + pay + " Won in Your Wallet.");
			return 0;
		}else {
			System.out.print("⚠️ Your Money is Not Enough To Buy!");
			Main_shop.SC.nextLine();
			return 1;
		}
		
	}
	public static void RefundPay(int pay) {//지갑에서 돈 차감
		Main_shop.u.Wallet += pay;
		System.out.print("+" +pay + " Won in Your Wallet.");
	}
	public static void ChargeMoney() {
		System.out.print("How much Charge in Your Wallet?:");
		int k = Main_shop.SC.nextInt();
		RefundPay(k);
	}
	public static void Search() { //검색 함수
		int k;
		System.out.println("======================================");
		System.out.print("How to search? \n 0: All \t\t 1: Name \n 2: Price \t 3: Category \n");
		System.out.println("======================================");
		System.out.print("Choose the Menu(0~3):");
		try {
			k = Main_shop.SC.nextInt();
			
			switch(k) {
				case 0:{
					cart.Search();
					break;
				}case 1:{
					System.out.print("Enter the name of the product : ");
					cart.Search(Main_shop.SC.next());
					Main_shop.SC.nextLine();
					break;
				}case 2:{
					System.out.print("Enter the range of price of the product(Low  High) : ");
					cart.Search(Main_shop.SC.nextInt(),Main_shop.SC.nextInt());
					break;
				}case 3:{
					System.out.print("Enter the price of the product : ");
					cart.Search(Main_shop.SC.next(), 1);
					Main_shop.SC.nextLine();
					break;
				}default:{
					System.out.println("⚠️ Please Enter correct value!(0~3)");
					Main_shop.SC.nextLine();
				}
			}
		}catch(InputMismatchException e) {
			System.out.println("⚠️ Enter corret type of name or amount!");
			Main_shop.SC.nextLine();
		}
	}
	
	public static void Refund() { //환불 함수
		System.out.println("======================================");
		System.out.println("The Product that you buyed");
		for(int i =0;i<Product.storage.buy.length;i++) {
			if(Product.storage.buy[i].getnum() > 0) {
				Product.storage.buy[i].show();
			}
		}
		System.out.println("======================================");
		System.out.print("Which Product Do You Want to Refund? : ");
		try {
			String name = Main_shop.SC.nextLine();
			System.out.print("How Many? : ");
			int num = Main_shop.SC.nextInt();
			Main_shop.SC.nextLine();
			Refund(name,num);
		}catch(InputMismatchException e) {
			System.out.println("⚠️ Enter corret type of name or amount!");
			Main_shop.SC.nextLine();			
		}
	}
	
	public static void Refund(String name,int num) {
		int k =0,j = 0; // k = 0 이면 올바른 이름이 없다는 뜻.
		int t = cart.minimumcart(Product.storage.buy,name ,num);
		if (t ==0) {
			try {
				for(int i = 0 ; i < Product.storage.buy.length ; i++) {
					if(Product.storage.buy[i].name.equalsIgnoreCase(name)) {
						int pay = Product.storage.buy[i].getprice() * num;
						RefundPay(pay);
						k++;
						j = storage.list[i].AddtoStorage(num);
						if(j != 0) { break; }
						Product.storage.buy[i].RemovefromCart(num);
						System.out.println(name + " "+ num + " Refunded.");
					}
				}
			}catch(ArrayIndexOutOfBoundsException e) {
				System.out.println("⚠️ An Internal Error Occured in Program!");
				Main_shop.SC.nextLine();
			}
			if(j !=0) { System.out.println("⚠️ Please Enter corret num!");	}
			if(k == 0) {System.out.println("⚠️ Please Enter corret name!");	}
		}
	}
}
