package Product;

public class product_3 extends product{
	String theme = "FRANK OCEAN";
	public product_3(String name, int num, int price) {
		this.name = name;
		this.num = num;
		this.price = price;
	}
	public product_3(String name, int price) {
		this.name = name;
		this.num = 0;
		this.price = price;
	}
	@Override
	public void show() { //dynamic binding
		System.out.println("[FRANK OCEAN]: " + name + "/ Num : " + num + " / " + price + " Won.");//제품 검색 출력
	}
	@Override
	public String gettheme() {
		return this.theme;
	};
}




