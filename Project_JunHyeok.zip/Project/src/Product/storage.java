package Product;

public class storage { //제품 class 들을 한번에 묶어서 관리하는 물류창고 역할
	 public static product[] list = {
			 	new product_1("Rodeo",10,80000), 
				new product_1("ASTROWORLD",5,100000),
				new product_1("UTOPIA",8,80000),
				new product_2("MBDTF",8,100000),
				new product_2("Graduation",9,80000),
				new product_2("VULUTURES2",5,60000),
				new product_3("Blonde",9,100000),
				new product_3("channel ORANGE",10,90000)
		    };
	 public static product[] cart = {
			 	new product_1("Rodeo",80000), 
				new product_1("ASTROWORLD",100000),
				new product_1("UTOPIA",80000),
				new product_2("MBDTF",100000),
				new product_2("Graduation",80000),
				new product_2("VULUTURES2",60000),
				new product_3("Blonde",100000),
				new product_3("channel ORANGE",90000)
		    };
	 public static product[] buy = {
			 	new product_1("Rodeo",80000), 
				new product_1("ASTROWORLD",100000),
				new product_1("UTOPIA",80000),
				new product_2("MBDTF",100000),
				new product_2("Graduation",80000),
				new product_2("VULUTURES2",60000),
				new product_3("Blonde",100000),
				new product_3("channel ORANGE",90000)
		    };
}
