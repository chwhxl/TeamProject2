package User;

import Main.management;
import java.util.*;

public class Lotto {
	User U = Main.Main_shop.u;
	
	public void LOTTO() {
		System.out.print("Lotto is 5000Won, How many Do You Want?: ");
		int num = Main.Main_shop.SC.nextInt();
		Main.Main_shop.SC.nextLine();
		int k = management.Payment(num*5000);
		if(k==0) {
			System.out.println();
			Random rand = new Random();
			for(int i=0;i<num;i++) {
				System.out.print((i+1)+ " :");
				int lt = rand.nextInt(11);
				management.RefundPay(lt * 1000);
				Main.Main_shop.SC.nextLine();
			}
		}
	}
}
