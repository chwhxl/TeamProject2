package User;

public class User {
	public int Wallet;
	public static cart c = new cart();
	public static Lotto l = new Lotto();
	public User() {
		Wallet = 5000000;
	}
}
