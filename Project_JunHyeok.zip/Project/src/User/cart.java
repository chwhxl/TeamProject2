package User;
import java.util.InputMismatchException;
import Main.*;
import Product.*;
public class cart {	
	
	public void Cart() {
		int k;
		System.out.println("======================================");
		System.out.print("How to search? \n 0: Show Cart \t 1: Add Cart \n 2: Remove from Cart\n");
		System.out.println("======================================");
		System.out.print("Choose the Menu(0~2):");
		try {
		k = Main_shop.SC.nextInt();
			switch(k){
				case 0:{
					showcart();
					Main_shop.SC.nextLine();
					break;
				}case 1:{
					AddCart();
					break;
				}case 2:{
					RemoveFromCart();
					break;
				}default:{
					System.out.println("⚠️ Please Enter corret num!");
				}
			}
		}catch(InputMismatchException e) {
			for (int i = 0; i < 15; i++) System.out.println();
			System.out.println("⚠️ Please Enter integer value!");	
		}
	}
	
	static int maximumcart(int num) { //입력받은 개수만큼 추가했을 시 카트가 가득차는가?
		int incart = 0;
		try {
			for(int i = 0 ; i < Product.storage.cart.length ; i++) {
				incart += Product.storage.cart[i].getnum();
			}
			if (incart + num <= 10) {
				return 0;
			}else {
				System.out.println("⚠️ Cart can has Maximum 10 Product!!");
				return 1;
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
			return 1;
		}
	}
	
	public static int minimumcart(Product.product []Product,String name,int num) { //입력받은 개수만큼 차감했을 시 카트가 -가 되는가?
		try {
			for(int i = 0 ; i < Product.length ; i++) {
				if(Product[i].name.equalsIgnoreCase(name)) {
					if(Product[i].getnum() - num < 0) {
						System.out.println("⚠️ You can't remove more items than the cart has!");
						return 1;
					}
				}
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
		}
		return 0;
	}

	public void showcart() { //카트 내용 다 보여주기(담은 것이 있는 것에 한해서)
		int a = 0;
		try {
			for(int i = 0 ; i < Product.storage.cart.length ; i++) {
				if(Product.storage.cart[i].getnum() > 0) {
					if (a==0) { System.out.println("In Your Cart"); }
						Product.storage.cart[i].show();
						a++;
				}
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
		}
		if (a == 0) { //카트에 아무것도 없으면
			System.out.println("Your Cart is Empty!");
		}
	}
	
	public int Cartprice() {
		int k = 0;
		try {
			for(int i = 0 ; i < Product.storage.cart.length ; i++) {
				if(Product.storage.cart[i].getnum() > 0) {
					k = (Product.storage.cart[i].getnum() * Product.storage.cart[i].getprice());
				}
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
		}
		return k;
	}
	
	public void AddCart() { //AddCart. 카트에 추가.
		int num;
		String name;
		//Scanner scanner = new Scanner(System.in);
		try {
			Main_shop.SC.nextLine();
			System.out.print("Input the name of product:");
			name = Main_shop.SC.nextLine();
			System.out.print("Input the amount of product:");		
			num = Main_shop.SC.nextInt();
			Main_shop.SC.nextLine();
			AddCart(name,num);
		}catch(InputMismatchException e) {
			System.out.println("⚠️ Enter corret type of name or amount!");
			Main_shop.SC.nextLine();
		}
		
	}
	
	public static void AddCart(String name,int num) {//카트에 추가 (over loading)
		int k =0,j = 0; // k = 0 이면 올바른 이름이 없다는 뜻.
		int t = maximumcart(num);
		if (t==0) {
			try {
				for(int i = 0 ; i < Product.storage.cart.length ; i++) {
					if(Product.storage.cart[i].name.equalsIgnoreCase(name)) {
						k++;
						j = storage.list[i].RemovefromStorage(num);
						if(j != 0) { break;}
						Product.storage.cart[i].AddtoCart(num);
						System.out.println(name + " "+ num + " Added");
					}
				}
			}catch(ArrayIndexOutOfBoundsException e) {
				System.out.println("⚠️ An Internal Error Occured in Program!");
				Main_shop.SC.nextLine();
			}
			if(j !=0) {System.out.println("⚠️ Please Enter corret num!");}
			if(k == 0) {System.out.println("⚠️ Please Enter corret name!");			}
		}
	}
	
	public static void RemoveFromCart() {
		String name;
		int num;
		try {
			Main_shop.SC.nextLine();
			System.out.print("Input the name of product:");
			name = Main_shop.SC.nextLine();
			System.out.print("Input the amount of product:");		
			num = Main_shop.SC.nextInt();
			Main_shop.SC.nextLine();
			RemoveFromCart(name,num);
		}catch(InputMismatchException e) {
			System.out.println("⚠️ Enter corret type of name or amount!");
			Main_shop.SC.nextLine();
		}
	}
	
	
	public static void RemoveFromCart(String name,int num) {
		int k =0,j = 0; // k = 0 이면 올바른 이름이 없다는 뜻.
		int t = minimumcart(Product.storage.cart,name ,num);
		if (t ==0) {
			try {
				for(int i = 0 ; i < Product.storage.cart.length ; i++) {
					if(Product.storage.cart[i].name.equalsIgnoreCase(name)) {
						k++;
						j = storage.list[i].AddtoStorage(num);
						if(j != 0) { break;}
						Product.storage.cart[i].RemovefromCart(num);
						System.out.println(name + " "+ num + " Removed");
					}
				}
			}catch(ArrayIndexOutOfBoundsException e) {
				System.out.println("⚠️ An Internal Error Occured in Program!");
				Main_shop.SC.nextLine();
			}
			if(j !=0) {System.out.println("⚠️ Please Enter corret num!");}
			if(k == 0) {System.out.println("⚠️ Please Enter corret name!");	}
		}
			
	}
	
	public static void Search() { //전체 검색
		Main_shop.SC.nextLine();
		for(int i = 0 ; i < Product.storage.cart.length ; i++) {
			storage.list[i].show();
			if((i % 3) == 21) {
				System.out.println("Press Enter to next page.");
				Main_shop.SC.nextLine();
			}
		}
	}
	public static void Search(String name) { //이름 검색
		try {
			for(int i = 0 ; i < Product.storage.cart.length ; i++) {
				if(storage.list[i].name.equalsIgnoreCase(name)) { //같은 이름이 있다면
					storage.list[i].show();
				}
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
		}
	}
	public static void Search(int lprice,int hprice) { //가격 검색
		try {
			for(int i = 0 ; i < Product.storage.cart.length ; i++) {
				if(lprice < storage.list[i].getprice() && storage.list[i].getprice() < hprice) { //원하는 가격대의 상품이 있다면
					storage.list[i].show();
				}
			}	
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
		}
		
	}
	public static void Search(String category, int key) {
		try {
			for(int i = 0 ; i < Product.storage.cart.length ; i++) {
				if(storage.list[i].gettheme().equalsIgnoreCase(category)) { //같은 카테고리가 있다면
					storage.list[i].show();
				}
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("⚠️ An Internal Error Occured in Program!");
			Main_shop.SC.nextLine();
		}
	}

}
