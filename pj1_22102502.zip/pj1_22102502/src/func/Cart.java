package func;

import item.Wine;
import java.util.Scanner;

public class Cart {
	
	private static final int ITEM_MAX = 10; 
	static Scanner in = new Scanner(System.in);
    
    private static Wine[] cart;
    
    static int itemCount=0;
    private static int totPrice;

    public Cart() {
    	this.cart = new Wine[ITEM_MAX];
    }

    public void addToCart(Wine wine) {
        if (itemCount < ITEM_MAX) {
            cart[itemCount] = wine; 
            System.out.println("❣ " + wine.name + " | "+wine.price+",000 won");
            System.out.print("🛒Succesfully added to your cart 🎀 ");
            System.out.println("( You can add "+ (ITEM_MAX-(itemCount+1)) + " more products✔)");
            itemCount++; 
            totPrice += wine.price;

        } else {
            System.out.println("Sorry your cart is full 😅" + " (Max: "+ ITEM_MAX + ")" );
        }

        
    }

    public static void showCart() {
        if (itemCount == 0) {
            System.out.println("Your cart is empty 😮");
        }
        else {
	        System.out.println("You added...");
	        System.out.println("------------------------------------------------------------");
	        for (int i = 0; i < itemCount; i++) {
	            System.out.println( (i+1) + ". " + cart[i].name+ " | " + cart[i].price+",000won");
	        }
	        System.out.println("Total: " + totPrice + ",000won");
        }
        System.out.println("-1. Go back to Shopping 0.Check out");
        int Select=in.nextInt();
        if(Select==0) {
        	Cart.checkout();
        }
        else if(Select==-1) {
        	ShowProduct.CategorySelect();
        }
        

    }

    public static void checkout() {

        if (itemCount == 0) {
            System.out.println("Oops! Your cart is empty...!");
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println( " '"+itemCount + "' items selected :");
        String Total = Cal(totPrice);
        System.out.println("Total : "+ Total +",000 won");
        System.out.println("Do you want to pay? 1.Yes 🤩 -1. Go Back ");
        int select=in.nextInt();
        if (select==1) {
        	System.out.println("Successfully ordered! 😍 Thank you for purchasing");
        }
        else if (select==-1) {
        	ShowProduct.CategorySelect();
        }
        		
        itemCount = 0; 
        totPrice=0;
        System.out.println("Thank you for visiting ! Hope to see you soon ! 🤗💌");
        System.exit(0);
        
    }
    
    private static String Cal(int totPrice) {
    	if (totPrice/1000>0) {
    		int Thousand= totPrice/1000;
    		int totprice= totPrice%1000;
    		return Integer.toString(Thousand)+","+Integer.toString(totprice);
    	}
    	else {
    		return Integer.toString(totPrice);
    	}
    	
    }
}
