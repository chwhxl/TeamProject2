package func;

public class LogIn {

}
