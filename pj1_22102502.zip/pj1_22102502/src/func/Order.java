package func;

import java.util.Scanner;

import item.*;

public class Order {
	static Scanner itemSelect = new Scanner(System.in);
	static Cart cart = new Cart();

	
	static void Order() {
		int item=itemSelect();
		Wine wine = new Wine();
		wine.WineList[item-1].ShowWine();
		System.out.println("1. Add to cart 0. See my cart 🛒 -1.Go back");
		int choose = itemSelect.nextInt();

		if (choose==1) {
			cart.addToCart(Wine.WineList[item-1]);
		}
		else if(choose==0) {
			cart.showCart();
		}
		else if (choose==-1) {
			ShowProduct.GoBack(ShowProduct.goback);
		}
		System.out.println("0.See my cart -1.Go back");
		int ContinueSelec=itemSelect.nextInt();
		if (ContinueSelec==0) {
			Cart.showCart();
		}
		else if (ContinueSelec==-1) {
			ShowProduct.GoBack(ShowProduct.goback);
		}
	}
	
	static void Order(int a) {
		int item=itemSelect();
		int item_i=item-1;
		int num=Wine.WINECOUNT;
		
		if (item>num && item<=2*num) {
			ItWine itwine = new ItWine();
			item_i=item_i-num;
			Wine.WineList[item_i].ShowWine();
		}
		else if(item> 2*num) {
			SpWine spwine = new SpWine();
			item_i=item_i-num*2;
			Wine.WineList[item_i].ShowWine();
		}
		else {
			FrWine frwine = new FrWine();
			Wine.WineList[item_i].ShowWine();
		}
		
		System.out.println("1. Add to cart 🛒 -1.Go back");
		int choose = itemSelect.nextInt();

		if (choose==1) {
			cart.addToCart(Wine.WineList[item_i]);
			
		}
		else if(choose==0) {
			cart.showCart();
		}
		else if (choose==-1) {
			ShowProduct.ShowAll();
		}	
		System.out.println("0.See my cart -1.Go back");
		int ContinueSelec=itemSelect.nextInt();
		if (ContinueSelec==0) {
			Cart.showCart();
		}
		else if (ContinueSelec==-1) {
			ShowProduct.ShowAll();
		}
	}
	
	protected static int itemSelect() {
		System.out.println("======================================================================");
		System.out.println("Enter the number of a product to see details");
		System.out.println("<0.See my Cart🛒 -1.Go back>");
		int item= itemSelect.nextInt();
		if (item==0) {
			cart.showCart();
		}
		else if (item==-1) {
			ShowProduct.CountrySelect();
		}
		return item;
	}

}

