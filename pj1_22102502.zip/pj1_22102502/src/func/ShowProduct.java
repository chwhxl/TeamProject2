package func;

import java.util.Scanner;

import item.*;

public class ShowProduct {
	
	static int goback;
	static Scanner select = new Scanner(System.in);
	static FrWine francewine =new FrWine();
	static ItWine italywine= new ItWine();
	static SpWine spainwine = new SpWine();
	static Order order = new Order();

	
	public static void CategorySelect(){
		System.out.println("Categories");
		System.out.println("1. Country 2. Wine Types 3. Show All");
		
		int CatSelect = select.nextInt();
		
		if (CatSelect==1) {
			CountrySelect();
		}
		else if (CatSelect==2) {
			TypeSelect();
		}
		else if (CatSelect==3) {
			ShowAll();
		}
	
	}
	
	static void ShowAll() {
		int num=0;
		System.out.println(" ------- Select Your Wine ------- ");
		num=francewine.showList(num);
		//10개씩 잘라서 show more 기능 만들면 더 예쁠 거 같음..
		num=italywine.showList(num);
		num=spainwine.showList(num);
		Order.Order(num);
	}

	private static void TypeSelect() {
		System.out.println("1.Red Wine 2.White Wine 0.Cart");
		
	}

	public static void CountrySelect() {
		int num=0;
		System.out.println("1.France 2.Italy 3.Spain -1.Go back to Categories");
		int CounSelect=select.nextInt();
		if(CounSelect==0) {
			Cart.showCart();
		}		
		else if(CounSelect==1) {
			goback=1;
			francewine.FrSelec();
		}
		else if(CounSelect ==2) {
			goback=2;
			italywine.ItSelec();
		}
		else if(CounSelect ==3) {
			goback=3;
			spainwine.SpSelec();
		}
		else if(CounSelect ==-1) {
			CategorySelect();
		}
		else {
			System.out.println("Sorry 😥, you pressed the wrong number.");
			System.out.println("Please try again");
			CountrySelect();
		}
		Order.Order();
		
	}
	
	
	public static void GoBack(int goback) {
	    if (goback==1) francewine.FrSelec();
		else if (goback==2) italywine.ItSelec();
		else if (goback==3) spainwine.SpSelec();
		Order.Order();
	}


}
