package item;

public class FrWine extends Wine{
	
	public FrWine() {
		WineList = new Wine[WINECOUNT];
		
		WineList[0]= new Wine("Domaine de la Croisée- Magma Pouilly-Fumé(2023)",
				0, 0, 75,              //country,type,price
				"0.5/0.2/0.8");
		
		WineList[1]= new Wine("Remy Nodin -Le Mazel Crozes Hermitage(2022)",
				0, 1, 50,
				"0.8/0.6/0.1/0.5");
		
		WineList[2]= new Wine("Jean-Louis Trocard -Clos de la Vieille Eglise Pomerol(2009)",
				0, 1, 45,
				"0.9/0.7/0.1/0.6");
		
		WineList[3]= new Wine("Château Labégorce-Margaux(2018)",
				0, 1, 50,
				"0.8/0.8/0.1/0.9");
		
		WineList[4]= new Wine("Domaine Vacheron-Sancerre Blanc(2020)",
				0, 0, 35,
				"0.3/0.0/0.8");
		
		WineList[5]= new Wine( "Château du Breuil-Clos du Frère Etienne Blanc(2022)",
				0, 0, 40,
				"0.4/0.0/1.0");
		
		WineList[6]= new Wine("Château Guiraud-Le G de Guiraud Bordeaux Blanc Sec(2023)",
				0, 0, 50,
				"0.7/0.2/0.5");
		
		WineList[7]= new Wine("Tinel-Blondelet-L'Arret Buffatte Pouilly-Fumé(2021)",
				0, 0, 55,
				"0.2/0.1/0.8");
		
		WineList[8]= new Wine("Château Belgrave -Haut-Médoc <Grand Cru Classé>(2018)",
				0, 1, 45,
				"0.8/0.8/0.1/0.8");
		
		WineList[9]= new Wine("Château de Chantegrive-Graves(2018)",
				0, 1, 50,
				"0.9/0.9/0.0/0.9");
		
		
	}
	

	public int showList(int num) {
		System.out.println();
		for  (int i=0; i<WINECOUNT;i++,num++) {
			System.out.print(num+1 +" : ");
			WineList[i].ShowName();
		}
		return num;
	}
	
	public void FrSelec() {
		System.out.println(" ------- Select Your French Wine ------- ");
		FrWine francewine =new FrWine();
		francewine.showList();
	}

}
