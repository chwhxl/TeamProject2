package item;

public class ItWine extends Wine {
	private static final int WINECOUNT =10;
	
	public ItWine() {
		WineList = new Wine[WINECOUNT];
		
		WineList[0]= new Wine("Feudi Bizantini-Il Rabdomante Montepulciano d'Abruzzo(2022)"
				,1,1,50,
				"0.5/0.4/0.3/0.6");
		
		WineList[1]= new Wine("Cà dei Frati-I Frati Lugana(2022)",
				1,0,35,
				"0.7/0.4/0.6");
		
		WineList[2]= new Wine("Cà dei Frati-Brolettino Lugana(2021)",
				1,0,50,
				"0.7/0.3/0.6"
);
		
		WineList[3]= new Wine("S. Cristina-Lugana(2022)",
				1,0,35,
				"0.6/0.3/0.5");
		
		WineList[4]= new Wine("Vigneti del Vulture-Moscato Sensuale(2018)",
				1,0,55,
				"0.6/0.4/0.3");
		
		WineList[5]= new Wine("Ornellaia-Le Volte(2022)",
				1,1,45,
				"0.6/0.5/0.1/0.5"
);
		
		WineList[6]= new Wine("Le Coste-Bianchetto(2023)",
				1,0,45,
				"0.5/0.3/0.8");
		
		WineList[7]= new Wine("Fantini-Fantini Edizione Bianco(N.A)",
				1,0,50,
				"0.5/0.6/0.6");
		
		WineList[8]= new Wine("Antinori-Castello della Sala San Giovanni della Sala Classico Superiore(2019)",
				1,0,30,
				"0.5/0.3/0.7");
		
		WineList[9]= new Wine("Soraighe-Valpolicella Ripasso Superiore(2020)",
				1,1,25,
				"0.7/0.4/0.4/0.3");
		
		
	}
	public int showList(int num) {
		ItWine italywine= new ItWine();
		System.out.println();
		for  (int i=0; i<WINECOUNT;i++,num++) {
			System.out.print(num+1 +" : ");
			WineList[i].ShowName();
		}
		return num;
	}
	
	public void ItSelec() {
		System.out.println(" ------- Select Your Italian Wine ------- ");
		ItWine italywine= new ItWine();
		italywine.showList();
	}


}
