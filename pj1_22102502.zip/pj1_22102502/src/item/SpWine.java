package item;

public class SpWine extends Wine{
	private static final int WINECOUNT =10;
	
	public SpWine() {
		WineList = new Wine[WINECOUNT];
		
		WineList[0]= new Wine("Bodegas Olarra-Cerro Añon Rioja Gran Reserva(2018)",
				2,1,35,
				"0.8/0.7/0.1/0.7");
		
		WineList[1]= new Wine("Bodega Cauzón-Iradei(2023)",
				2,1,45,
				"0.7/0.5/0.1/0.5");
		
		WineList[2]= new Wine("Bodegas Langa-Pasión(2013)",
				2,1,35,
				"1.0/0.5/0.2/0.5");
		
		WineList[3]= new Wine("Torremorón-Reserva(2017)",
				2,1,40,
				"0.8/0.7/0.0/0.8");
		
		WineList[4]= new Wine("Familia Torres-Viña Esmeralda(2021)",
				2,0,35,
				"0.5/0.4/0.5");
		
		WineList[5]= new Wine("Barranco Oscuro-Rubaiyat(2021)",
				2,1,45,
				"0.7/0.7/0.2/0.6");
		
		WineList[6]= new Wine("Barranco Oscuro-El Pino Rojo(2022)",
				2,1,45,
				"0.7/0.5/0.1/0.7");
		
		WineList[7]= new Wine("Monte Real-Tempranillo Blanco(2022)",
				2,0,25,
				"0.5/0.1/0.5");
		
		WineList[8]= new Wine("Barranco Oscuro-V de Valenzuela(2022)",
				2,0,45,
				"0.4/0.0/0.5");
		
		WineList[9]= new Wine("Viña Zorzal-Malayeto(2021)",
				2,1,35,
				"0.9/0.5/0.1/0.6");
		
		
	}
	
	public int showList(int num) {
		System.out.println();
		SpWine spainwine = new SpWine();
		for  (int i=0; i<WINECOUNT;i++,num++) {
			System.out.print(num+1 +" : ");
			WineList[i].ShowName();
		}
		return num;
	}
	
	public void SpSelec() {
		System.out.println(" ------- Select Your Spanish Wine ------- ");
		SpWine spainwine = new SpWine();
		spainwine.showList();
	}

}
