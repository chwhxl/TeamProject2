package item;

public class Wine {
	public String name;
	protected int country;
	protected int type;
	public int price;
	protected String detail;
	public static Wine[] WineList; 
	public static int winenum=0;
	public static final int WINECOUNT =10;
	
//	country: 0-France, 1-Italy, 3-Spain
//	type: 0-white wine, 1-red wine
	
	public Wine() {
		
	}
	
	public Wine(String name, int country, int type, int price, String detail) {
		this.name=name;
		this.country=country;
		this.type=type;
		this.price=price;
		this.detail=detail;
	}
	
	String CountryName ;
	String TypeName;
	
	public void showList() {
		System.out.println();
		for  (int i=0; i<WINECOUNT;i++) {
			System.out.print(i+1 +" : ");
			WineList[i].ShowName();
		}
	}
	public void ShowName() {
		System.out.print(name);
		System.out.println(" | Price: " + price + ",000 won");
		System.out.println();

	}
	public void ShowWine() {

		if (country==0) CountryName="France";
		else if(country==1) CountryName="Italy";
		else if(country==2) CountryName="Spain";
		
		if (type==0) {
			TypeName="White Wine";
			detail="(Boldness/Sweetness/Acidness) \n"+detail  ;
		}
		else if (type==1) {
			TypeName="Red Wine";
			detail="(Boldness/Tannic/Sweetness/Acidness) \n" +detail ;
		}
		
		System.out.println("❣ " + name);
		System.out.println("Country: "+ CountryName);
		
		System.out.println("Type : "+ TypeName);
		System.out.println("Taste\n" +detail);
		System.out.println("<Price: " + price + ",000 won>");
		System.out.println();
		
	}
	


}
