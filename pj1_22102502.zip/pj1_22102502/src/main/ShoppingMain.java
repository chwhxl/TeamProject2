package main;

import java.util.Scanner;

import func.Order;
import func.ShowProduct;

public class ShoppingMain {
	public static void main(String[] args) {
		
		String Nickname ="Guest";
		
		System.out.println("===========================================");
		System.out.println("(❁´◡`❁) Welcome to Jumi's Wine Shop ! 💘🎉🍷");
		System.out.println("===========================================");
		System.out.println("You want to shop as a...");
		System.out.println("0. Guest , 1. Member , 2. Sign Up");
		
		Scanner in =new Scanner(System.in);
		int LoginOption= in.nextInt();         
		if (LoginOption==0) {
			System.out.println("Hello, Mr./Mrs. Guest !💖");
			Nickname="Guest";
		}
		else if(LoginOption==1) {
			
		}
		int trial=0;
		while (trial==0) {
			try {
				
				while (trial==0) {
					ShowProduct.CategorySelect();
					System.out.println("Enter 0 to stay in this website");
					
				}
			}catch(Exception e){
				System.out.println("Sorry 😥, you pressed the wrong number.");
				System.out.println("Please try again");
				System.out.println("Enter 0 to stay in this website or press any other key to terminate");
			}
		
		trial=in.nextInt();
		}
		
		
		System.out.println("Thank you for visiting, my dear ! Hope to see you soon ! 🤗💌");
		in.close();
		
	}
}
